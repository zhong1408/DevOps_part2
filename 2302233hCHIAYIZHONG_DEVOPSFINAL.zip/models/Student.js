class Student{
    constructor(name,id,age,course,email){
        this.name = name;
        this.id = id;
        this.age = age;
        this.course = course;
        this.email = email;

    }
}

module.exports = { Student };